//
//  moveaddedgeMAIS.cpp
//  ClonOr
//
//  Created by Felipe Medina Aguayo on 01/03/2019.
//  Copyright © 2019 Felipe Medina Aguayo. All rights reserved.
//

#include "moveaddedgeMAIS.h"
#include <omp.h>
#include <algorithm>
//
using namespace std;
namespace weakarg
{
    
    MoveAddEdgeMAIS::MoveAddEdgeMAIS(Param *p,double a)
    : Move(p,a)
    {
        description= "Update adding a recombinant edge using MAISRJ";
        name= "AddEdge";
    }
    
    double MoveAddEdgeMAIS::gammaAIS(int t, int T_AIS){
        
        if(t==0)
            return 0;
        
        double result=pow((t+0.0)/T_AIS ,5);
        return(result);
    }
    
    double MoveAddEdgeMAIS::logSumExp(vector<double> x){
        
        double result=0;
        int n=x.size();
        
        double xmax=*(std::max_element(x.begin(),x.end()));
        
        for(int i=0; i<n; i++){
            x[i]-=xmax;
            result+=exp(x[i]);
        }
        result=log(result)+xmax;
        
        return(result);
    }
    
    vector<int> MoveAddEdgeMAIS::syst_resamp(vector<double> lw, int N){
        
        int sizeW=lw.size();
        vector<int> result(N);
        vector<double> lw_norm(sizeW);
        double lnormC=logSumExp(lw);
        
        for(int i=0; i<sizeW; i++){
            
            lw_norm[i]=lw[i]-lnormC;
        }
        
        double u=gsl_rng_uniform(rng);
        double C=0;
        int j=1;
        
        for (int i=0; i<N; i++){
            
            C+=exp(lw_norm[i]);
            while((u+j-1.0)/N<=C){
                
                result[j-1]=i;
                j+=1;
            }
        }
        
        return(result);
    }
    
    int MoveAddEdgeMAIS::mult_resamp(vector<double> lw){
    
        int sizeW=lw.size();
        int result;
        vector<double> lw_norm(sizeW);
        double lnormC=logSumExp(lw);
        
        for(int i=0; i<sizeW; i++){
            
            lw_norm[i]=lw[i]-lnormC;
        }
        
        double u=gsl_rng_uniform(rng);
        double C=0;
        int i=-1;
        
        while(u>C){
            
            i++;
            C+=exp(lw_norm[i]);
        }
        
        result=i;
        
        return(result);
    }
    
    int MoveAddEdgeMAIS::move(vector<int> * samplespace)
    {
        
        int T_AIS=param->getT_AIS();
        int N=param->getN_MAIS();
        RecTree* rectree0=param->getRecTree();
        
        vector<RecTree*> rectree_vec;
        vector<Param*> param_vec;
        for(int n=0;n<N;n++){
            
            param_vec.push_back(new Param(*param));
            rectree_vec.push_back(new RecTree(*rectree0));
            param_vec[n]->setRecTree(rectree_vec[n]);
            vector<Move*> mall_temp;
            param_vec[n]->setMall(mall_temp);
            
        }
        
        vector<double> lerror(N,0.0);
        vector<double> tfrom(N),tto(N);
        vector<unsigned int> start(N),end(N);
        vector<unsigned int> efrom(N),eto(N);
        vector<int> which(N);
        vector<vector<double> > store_ll0(N);
        vector<vector<double> > store_ll(N);
        vector<double> l(N), lratio(N,0.0);
        
        double l0=param->getLL(), lu=log(gsl_rng_uniform(rng)), lratio_avg=0;
        
        int n_threads=std::min(5,N);
        #pragma omp parallel num_threads(n_threads)
        {
            
            int id = omp_get_thread_num();
            int total = omp_get_num_threads();
            
            for(int i=0; i<N/n_threads; i++){
                
                int n=i+id*N/n_threads;
                //Draw start and end
                rectree_vec[n]->setBlock(&start[n],&end[n],param_vec[n]->getDelta(),param_vec[n]->getData()->getBlocks());
                
                //Draw eto and tto
                eto[n]=rectree_vec[n]->getPoint(&tto[n]);
                
                //Draw efrom and tfrom
                tfrom[n]=tto[n]+rectree_vec[n]->getNode(eto[n])->getAge();
                efrom[n]=rectree_vec[n]->getEdgeCoal(&tfrom[n]);
                tfrom[n]-=rectree_vec[n]->getNode(efrom[n])->getAge();
                
                #pragma omp critical
                {
                    which[n]=rectree_vec[n]->addRecEdge(tfrom[n],tto[n],start[n],end[n],efrom[n],eto[n]);
                }
                
                param_vec[n]->computeLikelihood(start[n],end[n]);
                l[n]=param_vec[n]->getLL();
                lratio[n]+=(gammaAIS(1,T_AIS)-gammaAIS(0,T_AIS))*l[n]-l0+log(param_vec[n]->getRho()*rectree_vec[n]->getTTotal()/2.0/rectree_vec[n]->numRecEdge());
            }
        }
        
        if(logSumExp(lerror)!=log(N))
            return -1;
        
        lratio_avg=logSumExp(lratio)-log(N);

        int k=mult_resamp(lratio);
        numcalls++;
        dlog(1)<<"Proposing to add edge via MAISRJ "<<efrom[k]<<":"<<tfrom[k]<<"->"<<eto[k]<<":"<<tto[k]<<"...";
        
        
        if (lu>lratio_avg)
        {
            dlog(1)<<"Rejected!"<<endl;
            /*param->setRecTree(rectree0);
            for (unsigned int i=start[k];i<end[k];i++)
                param->setlocLL(i,store_ll0[k][i-start[k]]);
            param->setLL(l0);*/
            
            /*
            for (vector<Param*>::iterator it = param_vec.begin() ; it != param_vec.end(); it++)
            {
                delete (*it);
            }
            param_vec.clear();
            */
            /*for (vector<RecTree*>::iterator it = rectree.begin() ; it != rectree.end(); it++)
            {
                delete (*it);
            }
            rectree.clear();*/
            //#pragma omp parallel for
            for(int i=0; i<N; i++){
                delete param_vec[i];
                delete rectree_vec[i];
            }
            //param_vec.clear();
            //rectree_vec.clear();
            vector<RecTree*>().swap(rectree_vec);
            vector<Param*>().swap(param_vec);

            return(0);
            //param->computeLikelihood(start,end);
        }
        else dlog(1)<<"Accepted!"<<endl;
        
        param->setRecTree(rectree_vec[k]);
        param->setlocLL_vec(param_vec[k]->getlocLL_vec());
        param->computeLikelihood(start[k],end[k]);
        param->setLL(l[k]);
        numaccept++;
        //delete rectree0;
        
        /*for (vector<Param*>::iterator it = param_vec.begin() ; it != param_vec.end(); it++)
        {
            delete (*it);
        }
        param_vec.clear();
        */
        /*for (vector<RecTree*>::iterator it = rectree.begin() ; it != rectree.end(); it++)
        {
            delete (*it);
        }
        rectree.clear();*/
        
        delete rectree0;
        //#pragma omp parallel for
        for(int i=0; i<N; i++){
            delete param_vec[i];
            if(i!=k)
                delete rectree_vec[i];
        }
        
        //param_vec.clear();
        //rectree_vec.clear();
        vector<RecTree*>().swap(rectree_vec);
        vector<Param*>().swap(param_vec);
        
        return(1);
    }
    
    MoveAddEdgeMAIS::~MoveAddEdgeMAIS()
    {}
    //
    
} // end namespace weakarg
